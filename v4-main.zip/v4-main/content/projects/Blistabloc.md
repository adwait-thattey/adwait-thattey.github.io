---
date: '2018-05-01'
title: 'blistabloc'
github: ''
external: 'https://blistabloc.com/'
tech:
  - WordPress
  - Timber
  - WooCommerce
company: 'Scout'
showInProjects: false
---

Custom WordPress theme and e-commerce site built with Timber and WooCommerce for blistabloc, a start-up selling the only reactive shoe insert that prevents blisters from forming.
