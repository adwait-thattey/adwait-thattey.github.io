---
date: '2017-08-01'
title: 'Interventions'
github: ''
external: 'https://interventions.design/'
tech:
  - Jekyll
  - SCSS
  - JS
company: 'Scout'
showInProjects: false
---

Interactive marketing website for Northeastern's first annual student-led design conference, Interventions.
