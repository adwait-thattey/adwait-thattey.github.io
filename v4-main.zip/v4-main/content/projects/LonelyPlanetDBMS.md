---
date: '2017-06-22'
title: 'Lonely Planet DBMS'
github: 'https://github.com/bchiang7/CS3200-Project'
external: ''
tech:
  - Python
  - MySQL
  - Flask
  - JS
company: 'Northeastern'
showInProjects: false
---

A simple web application that allows users to filter through and leave reviews in a database of Lonely Planet's Top 500 Travel Destinations.
