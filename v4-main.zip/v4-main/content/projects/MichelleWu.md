---
date: '2020-09-15'
title: 'Michelle Wu for Boston Grassroots Toolkit'
github: ''
external: 'https://toolkit.michelleforboston.com/'
tech:
  - Gatsby
  - Styled Components
company: 'Upstatement'
showInProjects: false
---
