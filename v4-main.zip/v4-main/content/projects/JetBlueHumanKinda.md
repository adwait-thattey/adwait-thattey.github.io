---
date: '2015-10-01'
title: 'JetBlue HumanKinda'
github: ''
external: 'https://us.mullenlowe.com/work/humankinda/'
tech:
  - Tumblr
  - HTML
  - CSS
  - JS
company: 'MullenLowe'
showInProjects: false
---

Tumblr site complementing JetBlue's HumanKinda campaign and documentary. Includes an interactive quiz to determine how "HumanKinda" you are. Learn more about this project [here](https://us.mullenlowe.com/work/humankinda/).
