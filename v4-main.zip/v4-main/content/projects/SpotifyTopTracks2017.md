---
date: '2018-04-20'
title: 'Spotify’s Top Tracks of 2017'
github: 'https://github.com/bchiang7/spotify-top-tracks-2017'
external: ''
tech:
  - R
  - Spotify Web API
company: 'Northeastern'
showInProjects: false
---

R Project for my Data Science class at Northeastern to analyze the top Spotify tracks of 2017 and their audio features.
