---
date: '2020-01-10'
title: 'Time to Have More Fun'
github: 'https://github.com/bchiang7/time-to-have-more-fun'
external: 'https://time-to-have-more-fun.now.sh/'
tech:
  - Next.js
  - Tailwind CSS
  - Firebase
company: ''
showInProjects: true
---

A single page web app for helping me choose where to travel, built with Next.js, Firebase, and Tailwind CSS
