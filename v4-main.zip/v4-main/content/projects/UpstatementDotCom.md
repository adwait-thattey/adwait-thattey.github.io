---
date: '2019-11-25'
title: 'Upstatement.com'
github: ''
external: 'https://www.upstatement.com/'
tech:
  - Nuxt
  - Vue
  - Prismic
company: 'Upstatement'
showInProjects: false
---
