---
date: '2015-12-01'
title: 'One Card For All'
github: ''
external: 'https://us.mullenlowe.com/work/one-card-for-all/'
tech:
  - HTML
  - SCSS
  - JS
  - jQuery
company: 'MullenLowe'
showInProjects: false
---

Interactive holiday site for MullenLowe built around an algorithm that generated a holiday greeting to each and every person on the planet. Check out this short [video](https://us.mullenlowe.com/work/one-card-for-all/) describing the project.
